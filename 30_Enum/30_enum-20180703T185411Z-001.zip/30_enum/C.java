enum CoffeeSize{
	BIG,HUGE,OVERWHELMING
}

class C{
	CoffeeSize cf;

	public static void main(String[] args) {
		C x = new C();
		System.out.println(x.cf);
	}
}
