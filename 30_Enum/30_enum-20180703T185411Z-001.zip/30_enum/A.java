//Please just compile and see the result;
void go(){

}