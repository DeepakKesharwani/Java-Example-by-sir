//See the compiled class
enum X{
	BIG,HUGE,OVERWHELMING
}