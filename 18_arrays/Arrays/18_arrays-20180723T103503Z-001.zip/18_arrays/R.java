class R{
	public static void main(String[] args){
		//Case 2:	
		int[] x = new byte[5];

		//Case 1:
		//byte b = 12;		
		//int u = b;
	}
}
