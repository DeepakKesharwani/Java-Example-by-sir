class U{
	public static void main(String[] args){
		int[][] x = new int[2][3];
		
		//System.out.println(x);
		//System.out.println(x.length);
		//System.out.println(x[0]);
		//System.out.println(x[1]);
		//System.out.println(x[2]);

		//System.out.println(x[0].length);
		//System.out.println(x[1].length);
		
		/*
		System.out.print(x[0][0]+" ");
		System.out.print(x[0][1]+" ");
		System.out.print(x[0][2]+" ");
		
		System.out.println();

		System.out.print(x[1][0]+" ");
		System.out.print(x[1][1]+" ");
		System.out.print(x[1][2]+" ");*/

		//System.out.print(x[0][3]+" ");		
	}
}