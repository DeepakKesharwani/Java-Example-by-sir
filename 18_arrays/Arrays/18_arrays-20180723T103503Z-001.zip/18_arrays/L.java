//Case 3:
/*
class L{
	public static void main(String[] args){
		//Case 2: // NOT OK
		//int[] x;
		//x = {44,12,78};

		//Case 1: //OK
		//int[] x;
		//x = new int[]{45,89,321};

		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
	}
}*/


//Case 2:
/*
class L{
	public static void main(String[] args){
		//Case 2:
		//int[] x = {2300,9000,3400};

		//Case 1:
		//int[] x = new int[]{230,900,340};

		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
	}
}*/


//Case 1:
/*
class L{
	public static void main(String[] args){
		int[] x = new int[3];

		x[0] = 23;
		x[1] = 90;
		x[2] = 34;

		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
	}
}*/