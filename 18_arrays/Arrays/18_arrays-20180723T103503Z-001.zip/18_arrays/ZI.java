class ZI{
	public static void main(String[] args){
		//Case 1:
		//Jumpable x;

		//Case 2:
		//Jumpable x = new Jumpable();

		//Case 3:
		Jumpable[] x = new Jumpable[2];
	}
}

//interface Jumpable{  }
//abstract class Jumpable{  }