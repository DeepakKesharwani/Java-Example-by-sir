class B{
	int[] x;

	public static void main(String[] args){
		B y = new B();
		System.out.println(y.x);
	}
}