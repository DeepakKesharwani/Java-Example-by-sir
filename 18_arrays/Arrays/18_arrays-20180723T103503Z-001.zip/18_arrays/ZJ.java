class ZJ{
	public static void main(String[] args){
		//int[] x = new int[2][3];
		//int[][] x = new int[2];
		//int[2][] x = new int[2][2];
		//int[][] x = {12,34,45};
		//int[] x = {{0,1,3}};
		//int[] x = new int[];
	}
}