class G{
	public static void main(String[] args){
		int[] x = new int[3];
		System.out.println(x.length);

		x.length = 5;
		
		System.out.println(x.length); 	
	}
}