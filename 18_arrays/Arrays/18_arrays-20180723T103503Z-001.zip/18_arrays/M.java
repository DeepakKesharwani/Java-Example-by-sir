
//Case 2:
/*
class M{
	public static void main(String[] args){
		int[] x = {23,90,34,55};

		for(int i=x.length-1;i>=0;i--){
			System.out.println(x[i]);
		}
	}
}*/

//Case 1:
/*
class M{
	public static void main(String[] args){
		int[] x = {23,90,34,55};

		for(int i=0;i<x.length;i++){
			System.out.println(x[i]);
		}
	}
}*/


