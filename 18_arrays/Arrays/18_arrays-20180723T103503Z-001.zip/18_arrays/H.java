class H{
	public static void main(String[] args){
		//Case 1:
		//int[] x = new int[3];

		//Case 2:
		//String[] x = new String[3];

		//Case 3:
		//boolean[] x = new boolean[3];
		
		//Case 4:
		float[] x = new float[3];

		
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
	}
}