class ZK{
	public static void main(String[] args){
		int[] y = {12,45,67};
		
		int[] z = pro(y);

		for(int e : z){
			System.out.println(e);
		}
	}

	static int[] pro(int[] x){
		return x;
	}
}