class I{
	public static void main(String[] args){
		String[] x = new String[2];
		
		x[0] = "mohan";
		x[1] = "ganesh";

		System.out.println(x[0]);
		System.out.println(x[1]);
	}
}