class O{
	public static void main(String[] args){
		String[] x = {"mohan","sohan","rohan","gohan","tohan"};
		
		//Case 2:
		for(String tmp : x){
			System.out.println(tmp+"~~~~");
		}

		//Case 1:
		/*
		for(int i=0;i<x.length;i++){
			System.out.println(x[i]);
		}*/
	}
}