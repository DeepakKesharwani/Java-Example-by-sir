class T{
	public static void main(String[] args){
		
		//Case 1:
		//int[] x = new int[4];

		//Case 2:
		//int[] x = new int[0];
		//System.out.println(x[0]);	

		//Case 3:
		//int[] x = new int[-1];

		//Case 4:
		//String[] x = new String[2.45f];

		//Case 5:
		//char e = 'E';
		//int[] x = new int[e];

		//Case 6:
		//int[] x = new int[3];
		//System.out.println(x[3]);
		
		System.out.println(x.length);
	} 
}