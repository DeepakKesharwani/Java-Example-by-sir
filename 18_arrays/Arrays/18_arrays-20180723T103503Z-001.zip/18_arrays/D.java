class D{
	static int[] x;

	public static void main(String[] args){
		System.out.println("~~~~~~~~~~~1");
		//System.out.println(x[0]);
		System.out.println(x.length);
		System.out.println("~~~~~~~~~~~2");
	}
}