class F{
	public static void main(String[] args){
		//int[] x = new int[3];
		//String[] x = new String[3]; 

		System.out.println(x);
	}
}