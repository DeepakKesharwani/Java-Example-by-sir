class H{
	public static void main(String[] args){
		System.out.println(Thread.currentThread().isAlive());
	}
}