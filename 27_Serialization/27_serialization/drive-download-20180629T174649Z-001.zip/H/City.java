class City{
	String cityName;

	City(String cityName){
		this.cityName = cityName;
	}
}