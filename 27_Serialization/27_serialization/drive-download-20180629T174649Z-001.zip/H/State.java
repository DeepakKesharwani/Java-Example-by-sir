class State{
	String stateName;

	State(String stateName){
		this.stateName = stateName;
	}
}