class H{
	class X{
		transient int y = 90;
	}
}