class D{
	transient void pro(){
	
	}
}