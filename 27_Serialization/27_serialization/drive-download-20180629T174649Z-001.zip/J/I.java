class I{
	void pro(){
		class A{
			transient int y;
		}
	}
}