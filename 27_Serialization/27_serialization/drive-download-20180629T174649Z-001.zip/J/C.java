class C{
	transient C(){
	
	}
}