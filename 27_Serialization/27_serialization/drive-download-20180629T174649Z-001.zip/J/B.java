transient class B{

}