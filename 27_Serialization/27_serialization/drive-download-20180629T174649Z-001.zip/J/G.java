class G{
	transient class X{

	}
}