class F{
	transient {
	
	}
}