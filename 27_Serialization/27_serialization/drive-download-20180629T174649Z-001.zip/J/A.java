class A{
	transient static int y = 90;
}