class E{
	void pro(){
		transient int y = 90;
	}
}