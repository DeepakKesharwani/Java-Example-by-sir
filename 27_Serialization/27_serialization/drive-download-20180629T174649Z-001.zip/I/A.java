import java.io.Serializable;

class A implements Serializable{
	int x;
	static int y;
}