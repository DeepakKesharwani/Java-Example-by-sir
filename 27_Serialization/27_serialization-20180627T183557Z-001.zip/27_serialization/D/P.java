import java.util.Date;

class P{
	int a;
	boolean flag;
	Date date;
}