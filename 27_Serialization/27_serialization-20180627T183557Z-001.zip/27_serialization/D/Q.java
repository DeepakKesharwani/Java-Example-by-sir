import java.io.Serializable;



class Q extends P implements Serializable{
	float g;
	char m;
}