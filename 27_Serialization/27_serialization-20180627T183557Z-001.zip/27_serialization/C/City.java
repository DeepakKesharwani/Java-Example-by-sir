class City{
	String cityName;
}