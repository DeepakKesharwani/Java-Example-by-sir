class State{
	String stateName;
}