import java.io.Serializable;

class Q extends P implements Serializable{
	int t;
}