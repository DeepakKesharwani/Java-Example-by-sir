class P{
	Student student = new Student("vikas",22);
	int y = 78;
}