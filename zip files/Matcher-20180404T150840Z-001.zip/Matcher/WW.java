class WW{
	public static void main(String[] args){
		System.out.println("sohan\rg");
	}
}