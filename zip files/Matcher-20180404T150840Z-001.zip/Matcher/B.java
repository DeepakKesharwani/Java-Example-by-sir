import java.util.regex.*; 

class B
{		
	public static void main(String[] args){
		//Case 1:
		//Pattern p = Pattern.compile("mohan");
		//Pattern p = Pattern.compile("\\d");
		//System.out.println(p);

		//Case 2:
		Pattern p = Pattern.compile("mohan");
		Matcher m = p.matcher("mohan is a good boy");
		System.out.println(m);

		//Case 3:
		//Pattern p = Pattern.compile("mohan");
		//System.out.println(p.pattern());
		//System.out.println(p);

		//Case 4:
		
		//Pattern p = Pattern.compile("mohan");
		//Matcher m = p.matcher("mohan is a good boy");
	    //System.out.println(m.pattern());
		//System.out.println(p);
		//System.out.println(p.pattern());
	}
}

