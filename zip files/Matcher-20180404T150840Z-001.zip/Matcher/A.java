//import java.util.regex.*; //---1.

class A
{		
	public static void main(String[] args){
		//See the source code f the class
		//Pattern p = new Pattern(); // --- 2. //Does not exists
		Pattern p = new Pattern("abc",0); // -- 3. 
	}
}

