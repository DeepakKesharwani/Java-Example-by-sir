class G 
{
	public static void main(String[] args) 
	{
		enum CoffeeSize{
			BIG,HUGE,OVERWHELMING
		};
	}
}
