import java.util.EventListener;

interface FormActionListener extends EventListener{
	void formActionOccurred(FormEvent event);
}