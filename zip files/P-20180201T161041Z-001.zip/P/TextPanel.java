import javax.swing.*;
import java.awt.*;

class TextPanel extends JPanel{
	
	JTextArea textArea;

	TextPanel(){
		setLayout(new BorderLayout());

		textArea = new JTextArea();	
		add(new JScrollPane(textArea),BorderLayout.CENTER);
	}

	void appendText(String str){
		textArea.append(str);
	}
}