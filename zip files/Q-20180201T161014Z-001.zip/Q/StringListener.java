interface StringListener{
	void textWriter(String str);
}