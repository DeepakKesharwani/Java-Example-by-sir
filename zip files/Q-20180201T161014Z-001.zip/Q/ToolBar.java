import javax.swing.*;
import java.awt.FlowLayout;

import java.awt.event.*;

class ToolBar extends JPanel implements ActionListener{
	JButton btn1,btn2;
	StringListener stringListener;
	//TextPanel textPanel;

	ToolBar(){
		setLayout(new FlowLayout(FlowLayout.LEFT));

		btn1 = new JButton("Hello");
		btn1.addActionListener(this);
		add(btn1);

		btn2 = new JButton("Bye");
		btn2.addActionListener(this);
		add(btn2);

		setBorder(BorderFactory.createEtchedBorder());
	}
	
	void setStringListener(StringListener stringListener){
		this.stringListener = stringListener;
	}
	/*
	void setTextPanel(TextPanel textPanel){
		this.textPanel = textPanel;
	}*/

	public void actionPerformed(ActionEvent e){		
		JButton btn = (JButton)e.getSource();
		
		if(btn==btn1){
			stringListener.textWriter("Hello#\n");
			//textPanel.appendText("Hello\n");
		}else{
			stringListener.textWriter("Bye#\n");
			//textPanel.appendText("Bye\n");	
		}
	}
}