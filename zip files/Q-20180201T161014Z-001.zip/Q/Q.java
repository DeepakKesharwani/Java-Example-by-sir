import javax.swing.*;

class Q{
	public static void main(String[] args){
		SwingUtilities.invokeLater(new Runnable(){
										public void run(){
											new MyFrame();
										}
								   });
	}
}

