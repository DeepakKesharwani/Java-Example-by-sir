import java.util.EventObject;

class FormEvent extends EventObject{
	private String name;
	private String email;

	FormEvent(Object source){
		super(source);
	}

	FormEvent(Object source,String name,String email){
		super(source);

		this.name = name;
		this.email = email;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}
}