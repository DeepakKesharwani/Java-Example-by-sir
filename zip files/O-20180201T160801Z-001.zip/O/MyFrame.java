import javax.swing.*;
import java.awt.*;

import java.awt.event.*;

class MyFrame extends JFrame{
	private ToolBar toolBar;
	private TextPanel textPanel;
	private FormPanel formPanel;

	MyFrame(){
		super("My App");
		
		setSize(600,500);
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

		toolBar = new ToolBar();
		add(toolBar,BorderLayout.NORTH);

		textPanel = new TextPanel();
		add(textPanel,BorderLayout.CENTER);	

		formPanel = new FormPanel();
		add(formPanel,BorderLayout.WEST);

		formPanel.setFormActionListener(new FormActionListener(){
											public void formActionOccurred(FormEvent event){
												textPanel.appendText(event.getName()+"-"+event.getEmail());
											}
										});
		
		//toolBar.setTextPanel(textPanel);
		toolBar.setStringListener(new StringListener(){
									public void textWriter(String str){
										textPanel.appendText(str);
									}
								  });
	}
}