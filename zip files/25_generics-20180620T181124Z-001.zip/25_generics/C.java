import java.util.*;

class C{
	public static void main(String[] args){
		//Case 2:
		/*
		int[] x = new int[4];

		x[0] = true;
		x[1] = 23.45;
		x[2] = "mohan";
		x[3] = new A(); 
		*/
		
		
		//Case 1:
		/*
		ArrayList x = new ArrayList();

		x.add(12);
		x.add("mohan");
		x.add(new Date());
		x.add(new A());
		x.add(true);

		System.out.println(x);
		*/
	}
}