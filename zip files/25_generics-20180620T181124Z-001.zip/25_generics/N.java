import java.util.*;

class N{
	public static void main(String[] args){
		ArrayList<Integer> x = new ArrayList<Integer>();

		x.add(12);
		x.add(67);
		x.add(89);

		pro(x);
	}

	static void pro(ArrayList<Number> arr){
		
	}
}