import java.util.*;

class H{
	public static void main(String[] args){
		//Case 3:
		ArrayList list = new ArrayList<Integer>();
		
		//Case 2:
		//ArrayList<Number> list = new ArrayList();


		//Case 1:
		//ArrayList<Number> list = new ArrayList<Integer>();
	}
}