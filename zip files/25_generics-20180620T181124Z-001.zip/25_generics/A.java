import java.util.*;

class A{
	public static void main(String[] args){
		//Case 3://NOT OK
		//List<Number> list = new ArrayList<Integer>();
		
		//Case 2:
		//List<Integer> list = new ArrayList<Integer>();
		
		//Case 1:
		//List list = new ArrayList();		
		//list.add(12);
	}
}