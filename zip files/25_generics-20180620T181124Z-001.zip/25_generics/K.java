import java.util.*;

class K{
	public static void main(String[] args){
		//ArrayList<K> arr = new ArrayList<K>();
		//ArrayList<W> arr = new ArrayList<W>();
		//ArrayList<R> arr = new ArrayList<R>();
		//ArrayList<int> arr = new ArrayList<int>();
		//ArrayList<Integer[]> arr = new ArrayList<Integer[]>();
		ArrayList<int[]> arr = new ArrayList<int[]>();
	}
}

abstract class W{ }

interface R{ } 