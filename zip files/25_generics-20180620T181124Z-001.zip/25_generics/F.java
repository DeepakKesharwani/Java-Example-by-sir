import java.util.*;

class F{
	public static void main(String[] args){
		
		//Case 2:
		/*
		ArrayList x = new ArrayList();

		x.add(12);
		x.add("mohan");
		x.add(new Date());
		x.add(new A());
		x.add(true);
		
		String str = (String)x.get(1);
		*/
		
		
		//Case 1:
		/*
		ArrayList x = new ArrayList();

		x.add(12);
		x.add("mohan");
		x.add(new Date());
		x.add(new A());
		x.add(true);
		
		String str = x.get(1);
		*/
	}
}





