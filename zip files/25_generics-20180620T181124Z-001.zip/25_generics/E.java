import java.util.*;

class E{
	public static void main(String[] args){
		ArrayList<String> x = new ArrayList<String>();

		x.add(12);
		x.add("mohan");
		x.add(new Date());
		x.add(new A());
		x.add(true);	
	}
}