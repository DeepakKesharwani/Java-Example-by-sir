class E4{
	class F4{

	}
}

class Z extends E4{
	Z.F4 t = new F4();
}