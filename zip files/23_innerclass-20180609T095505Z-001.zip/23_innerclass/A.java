//inner classes cannot have static declarations

class A {
	class B{
		static int a = 90;

		static void go(){
		
		}
	}
}
