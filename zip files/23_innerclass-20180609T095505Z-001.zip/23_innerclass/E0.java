class E0 {

	//Case 1:
	//static F0 x = new F0();

	//Case 2:
	//F0 x = new F0();

	//Case 3:
	//static F0 x;

	//Case 4:
	//static E0 y = new E0();
	//static F0 x = y.new F0();

	class F0{

	}	
}









