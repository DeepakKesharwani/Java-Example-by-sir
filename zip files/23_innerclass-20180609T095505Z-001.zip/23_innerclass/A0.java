class A0 {
	class B0 {
		
	}
}
