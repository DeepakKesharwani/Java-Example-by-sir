import java.util.LinkedHashSet;

class D{
	public static void main(String[] args){
		LinkedHashSet set = new LinkedHashSet();

		set.add(12);
		set.add(3);
		set.add(14);
		set.add(5);
		set.add(16);
		set.add(8);

		System.out.println(set);
	}
}