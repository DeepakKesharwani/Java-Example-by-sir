import java.util.TreeSet;

class E{
	public static void main(String[] args){
		TreeSet set = new TreeSet();
		
		//Case 2:
		set.add("ganesh");
		set.add("eanesh");
		set.add("tanesh");
		set.add("ianesh");
		set.add("aanesh");


		//Case 1:
		/*
		set.add(12);
		set.add(3);
		set.add(14);
		set.add(5);
		set.add(16);
		set.add(8);*/

		System.out.println(set);
	}
}