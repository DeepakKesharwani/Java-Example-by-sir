import java.util.TreeMap;
import java.util.SortedMap;

class E{
	public static void main(String[] args){
		TreeMap map = new TreeMap();

		map.put("mohan", 23);
		map.put("sohan", 12);
		map.put("tohan", 5);
		map.put("rohan", 56);
		map.put("gohan", 2);

		//SortedMap sm = map.headMap("nitin");
		//SortedMap sm = map.tailMap("R");
		//System.out.println(sm);
	
		//System.out.println(map);
		/*
		System.out.println(map.firstKey());
		System.out.println(map.lastKey());
		*/

	}
}