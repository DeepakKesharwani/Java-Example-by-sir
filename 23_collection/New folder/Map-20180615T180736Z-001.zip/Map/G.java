import java.util.TreeMap;

class G{
	public static void main(String[] args){
		TreeMap map = new TreeMap();
		
		//Case 1:
		/*
		map.put(12,"mohan");
		map.put(45,"sohan");
		map.put(5,"rohan");
		map.put(32,"gohan");
		map.put(57,"tohan");*/

		//Case 2:
		/*
		map.put("mohan", 12);
		map.put("sohan", 34);
		map.put("rohan", 56);
		map.put("gohan", 9);
		map.put("tohan", 14);*/

		System.out.println(map);
	}
}