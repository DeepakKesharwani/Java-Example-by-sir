import java.util.HashMap;

class C{
	public static void main(String[] args){
		HashMap map = new HashMap();

		map.put(12,null);
		map.put(45,"sohan");
		map.put(null,"rohan");
		map.put(32,"gohan");
		map.put(57,null);
		map.put(null,"sarvesh");

		System.out.println(map);		
	}
}






















