import java.util.HashMap;

class B{
	public static void main(String[] args){
		HashMap map = new HashMap();

		map.put(12,"mohan");
		map.put(45,"sohan");
		map.put(5,"rohan");
		map.put(32,"gohan");
		map.put(57,"tohan");

		System.out.println(map);

		map.put(5,"rajesh");
		
		System.out.println(map);
	}
}






















