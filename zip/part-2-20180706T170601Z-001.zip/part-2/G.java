import java.io.Console;

class G{
	public static void main(String[] args){
		Console con = System.console();

		char[] passw = con.readPassword();
		System.out.println("###############");
		for(char c : passw){
			System.out.print(c);
		}


		//Case 1:
		//String str = con.readLine();
		//System.out.println("###############");
		//System.out.println(str);
	}
}