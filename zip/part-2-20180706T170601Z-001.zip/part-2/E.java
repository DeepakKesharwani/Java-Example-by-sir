class E{
	public static void main(String[] args){
		//Case 2:
		String str = "moha23n i2s le567arn67in4g ja6va";
		String[] tokens = str.split("\\d\\d");
		
		//Case 1:
		//String str = "mohan is learning java";
		//String[] tokens = str.split(" ");

		for(String st : tokens){
			System.out.println(st);
		}
	}
}