class A{
	public static void main(String[] args){
		
		//Case 3:
		
		String str = new String(" ");
		System.out.println(str.length());
		
		StringBuffer sbuff = new StringBuffer(" ");
		System.out.println(sbuff.length());
		


		//Case 2:
		
		//String str = new String("");
		//System.out.println(str.length());
		
		//StringBuffer sbuff = new StringBuffer("");
		//System.out.println(sbuff.length());
		

		//Case 1:
		
		//String str = new String();
		//System.out.println(str.length());
		
		//StringBuffer sbuff = new StringBuffer();
		//System.out.println(sbuff.length());
			
	}
}