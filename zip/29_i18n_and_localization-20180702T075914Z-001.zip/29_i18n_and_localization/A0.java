import java.util.Date;

class A0 {
	public static void main(String[] args) {
		Date dt = new Date();
		System.out.println(dt);
		System.out.println(dt.getTime());
	}
}
