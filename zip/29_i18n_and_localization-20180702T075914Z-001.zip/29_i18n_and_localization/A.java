import java.util.Date;

class A {
	public static void main(String[] args) {
		Date dt = new Date(-887894358395L);
		System.out.println(dt);
		System.out.println(dt.toString());
	}
}
