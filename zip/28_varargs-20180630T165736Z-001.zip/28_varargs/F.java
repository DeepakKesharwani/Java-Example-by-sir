interface F{
	void go(int... x);
}