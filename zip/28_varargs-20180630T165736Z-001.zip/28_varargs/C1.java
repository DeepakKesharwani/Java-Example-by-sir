class C1{
	public static void main(String... args){
		//Case 1:
		short sh = 12;

		//Case 2:
		//process(12);
		
		//Case 3:
		//short sh = process();

		//Case 4:
		//process(12,34);

		//Case 5:
		//byte[] e = {128,34,56};
	}

	//Case 4:
	/*
	static void process(short... x){
	
	}*/

	//Case 3:
	/*
	static short process(){
		return 23;
	}*/
	
	//Case 2:
	/*
	static void process(short sh){
	
	}*/
}

















