import java.util.*;

class P{
	public static void main(String[] args){
		ArrayList<? extends Number> x = new ArrayList<Integer>();

		x.add(12);
	}
}