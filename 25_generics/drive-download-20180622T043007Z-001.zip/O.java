import java.util.*;

class O{
	public static void main(String[] args){
		ArrayList<? extends Number> x = new ArrayList<Integer>();
		//ArrayList<Number> x = new ArrayList<Integer>();
	}
}